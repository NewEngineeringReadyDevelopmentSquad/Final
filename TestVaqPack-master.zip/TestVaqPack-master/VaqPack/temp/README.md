#This folder needs:
* .pdf
* .html
