#This folder needs:
* folders of courses
* xml files of those courses in those folders
